<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('barang.update', [$barang->kd_brg])); ?>" method="POST">
 <?php echo csrf_field(); ?>
 <input type="hidden" name="_method" value="PUT">
 <fieldset>
 <legend>Ubah Data Barang</legend>
 <div class="form-group row">
 <div class="col-md-5">
 <label for="addkdbrg">Kode Barang</label>
 <input class="formcontrol" type="text" name="addkdbrg" value="<?php echo e($barang->kd_brg); ?>" readonly>
 </div>
 <div class="col-md-5">
 <label for="addnmbrg">Nama Barang</label>
 <input id="addnmbrg" type="text" name="addnmbrg" class="formcontrol" value="<?php echo e($barang->nm_brg); ?>">
 </div>
 <div class="col-md-5">
 <label for="Harga">Harga</label>
 <input id="addharga" type="text" name="addharga" class="formcontrol" value="<?php echo e($barang->harga); ?>">
 </div>
 <div class="col-md-5">
 <label for="Stok">Stok</label>
 <input id="addstok" type="text" name="addstok" class="formcontrol" value="<?php echo e($barang->stok); ?>">
 </div>
 </fieldset>
 <div class="col-md-10">
 <input type="submit" class="btn btn-success btn-send" value="Update">
 <a href="<?php echo e(route('barang.index')); ?>"><input type="Button" class="btn-primary btn-send" value="Kembali"></a>
 </div>
 <hr>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DIplomat\resources\views/admin/editBarang.blade.php ENDPATH**/ ?>