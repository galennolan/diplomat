<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
 <h1 class="h3 mb-0 text-gray-800">Data Pengguna</h1>
</div><hr>
<div class="card-header py-3" align="right">
 <button class="btn btn-primary btn-sm btn-flat" data-toggle="modal" data-target="#modal-add"><i class="fa fa-plus"></i>Tambah</button>
</div>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
 <div class="card-body">
    <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
        <tr align="center">
        <th width="5%">User Id</th>
        <th width="25%">Nama</th>
        <th width="20%">Email</th>
        <th width="15%">Roles/Akses</th>
        <th width="25%">Aksi</th>
        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($row->id); ?></td>
        <td><?php echo e($row->name); ?></td>
        <td><?php echo e($row->email); ?></td>
        <?php $__currentLoopData = $row->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td>
        <?php echo e($r->id); ?>

 </td>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <td align="center">
 <a href="<?php echo e(route( 'user.edit',[$row->id])); ?>" class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm">
    <i class="fas fa-edit fa-sm text-white-50"></i>Edit Akses
    </a>
 <a href="/user/hapus/<?php echo e($row->id); ?>" onclick="return confirm('Yakin Ingin menghapus data?')" class="d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm">
 <i class="fas fa-trash-alt fa-sm text-white-50"></i> Hapus
 </a>
 </td>
 </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody>
 </table>
 </div>
 </div>
</div>
<!-- modal add data-->
<div class="modal inmodal fade" id="modal-add" tabindex="-1" role="dialog" aria-hidden="true">
 <div class="modal-dialog modal-xs">
 <form name="frm_add" id="frm_add" class="form-horizontal" action="#" method="POST" enctype="multipart/form-data">
 <?php echo csrf_field(); ?>
 <div class="modal-content">
 <div class="modal-header">
 <h4 class="modal-title">Tambah Data User</h4>
 </div>
 <div class="modal-body">
 <div class="form-group"><label class="col-lg-20 control-label">Nama User</label>
 <div class="col-lg-10"><input type="text" name="username" required
 class="form-control"></div>
 <div class="form-group"><label class="col-lg-20 control-label">Email User</label>
 <div class="col-lg-10"><input type="email" name="email" required
 class="form-control"></div>
 <div class="form-group"><label class="col-lg-20 control-label">Roles/Akses</label>
 <div class="col-lg-10">
 <select id="roles" name="roles" class="form-control" required>
 <option value="">--Pilih Roles--</option>
 <option value="ADMIN">Admin</option>
 <option value="USER">User</option>
 </select>
 </div>
</div>
 </div>
 <div class="modal-footer">
 <button type="button" class="btn btn-light" datadismiss="modal">Tutup</button>
 <button type="submit" class="btn btn-primary">Simpan</button>
 </div>
<?php $__env->stopSection(); ?>
 </div>
 </form>
 </div>
</div>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DIplomat\resources\views/admin/user.blade.php ENDPATH**/ ?>