<?php $__env->startSection('content'); ?>
<div class="container">
 <div class="row justify-content-center">
 <div class="col-md-12">
 <div class="card">
 <div class="cardheader">Laporan Stok</div>
 <div class="table-responsive">
 <table class="table table-striped table-hover table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
 <thead>
 <tr>

 <th>Kode</th>
 <th>Nama</th>
 <th>Stok Awal</th>
 <th>Beli</th>
 <th>Retur</th>
 <th>Stok Total (Stok+Beli-retur)</th>
 </tr>
 </thead>
 <tbody>
 <?php
 foreach ($data as $item):
 ?>
 <tr>
 <td><?php echo e($item->kd_brg); ?></td>
 <td><?php echo e($item->nm_brg); ?></td>
 <td><?php echo e(number_format($item->stok,0,',','.')); ?></td>
 <td><?php echo e(number_format($item->beli,0,',','.')); ?></td>
 <td><?php echo e(number_format($item->retur,0,',','.')); ?></td>
 <td><?php echo e(number_format(($item->stok+$item->beli)-$item->retur)); ?></td>
 </tr>
 <?php
 endforeach;
 ?>
 </tbody>
 </table>
 </div>
 </div>
 </div>
 </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DIplomat\resources\views/laporan/stok.blade.php ENDPATH**/ ?>