<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Customer Report</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                <button class="btn btn-sm btn-outline-secondary">Share</button>
                <button class="btn btn-sm btn-outline-secondary">Export</button>
              </div>
              <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
              </button>
            </div>
            
          </div>
        <div class="row g-2 ">
        <div class="col-md">
            <label class="font-weight-bold" for="exampleFormControlSelect1">Area</label>
            <select class="form-control" id="exampleFormControlSelect1">
            <option>Solo</option>
            <option>Karanganyar</option>
            <option>Wonogiri</option>
            <option>Sukoharjo</option>
            <option>Sragen</option>
            </select>
        </div>
        </div>

        <div class="row g-2">
        <div class="col-md">
        <div class="form-floating">
          <label for="exampleFormControlInput1">Tanggal Transaksi</label>
          <input type="date" min="1" name="tgl" id="addnmbrg" class="form-control" id="exampleFormControlInput1" required >
          </div>
          </div>
          <div class="col-md">
        <div class="form-floating">
          <label for="exampleFormControlInput1">Tanggal Transaksi</label>
          <input type="date" min="1" name="tgl" id="addnmbrg" class="form-control" id="exampleFormControlInput1" required >
          </div>
          </div>
        </div>
        <div class="charts">

        <canvas class="my-4" id="myChart" style="width:50%;max-width:600px"></canvas>

        
        </div>

<script>


var xValues = ["PUSAT PERBELANJAAN", "WARTEG", "SC", "KANTOR", "PA"];
var yValues = [55, 49, 44, 24, 15,8];
var barColors = ["red", "green","blue","orange","brown"];

new Chart("myChart", {
  type: "bar",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "Venue"
    }
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DIplomat\resources\views/customerReport.blade.php ENDPATH**/ ?>